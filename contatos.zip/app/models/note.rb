class Note < ActiveRecord::Base
  belongs_to :contato
end
