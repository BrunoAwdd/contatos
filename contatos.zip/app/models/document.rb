class Document < ActiveRecord::Base
  belongs_to :product
end
