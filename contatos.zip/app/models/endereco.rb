class Endereco < ActiveRecord::Base
  belongs_to :contato
end
