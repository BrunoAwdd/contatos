class ContatoMailer < ApplicationMailer
  default from: 'alternative@alternativefinance.com.br'

  def hello_email(contato)
    @contato = contato
    @url = 'http://www.alternativefinance.com.br'
    mail(to: 'bruno@alternativefinance.com.br', subject: 'Hello World')
  end
end
