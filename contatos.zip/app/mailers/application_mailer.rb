class ApplicationMailer < ActionMailer::Base
  default from: "contato@alternativefinance.com.br"
  layout 'mailer'
end
